<?php
#
#  worldextremes.php - Last modified: 02 Dec 2010 @ 15h00
#
############################################################################
#
#   Project:    World Weather Extremes
#   Module:     worldextremes.php
#   Purpose:    Provides World Weather Extremes for Web page display
#   Authors:    Michael (michael@relayweather.com)
#               Ray (ray@tzweather.org) Rev 5 additions
#   Source:     Data Compiled and Provided by ogimet.com
############################################################################
############################################################################
// version
$weatherextremesverion = "0.5";
// Ver0.1 23-Nov-10 -- Updated the script to change the temp or precip values
//                     font color to suite the cell background color.
//                     There were some instances of black font with very
//                     dark cell color which made it hard to read.
// Ver0.2 24-Nov-10 -- Added Station Identification to tables and ID Lookup
// Ver0.3 25-Nov-10 -- Also added ogimet server overload handling
// Ver0.4 26-Nov-10 -- Improved ogimet server overloading handling function. 
// Ver0.5 02-Dec-10 -- Added multi-area functionality (Thanks to Ray @ Tzouhalem-Maple Bay Weather www.tzweather.org)
//
echo "<!-- Weather Extremes Script Version $weatherextremesverion -->\n";
date_default_timezone_set('UTC');
$year       = date("Y");
$month      = date("m");
$monthname  = date("F");
$day        = date("d");
$daynumber  = date("jS");
$hour       = date("H");
/////////////////////////////////////////////////////////////////////////////
//SETTINGS START HERE////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
// Select country or location
// Go here (http://www.ogimet.com/ranking.phtml.en), select your country and look in the URL for the country abbr.
// Examples: 'World' = world, 'North' = Northern Hemisphere, 'South' = Southern Hemisphere, 'Eur' = Europe, etc.
// Examples: 'Cana' = Canada, 'United+S' = United States, 'Eur' = Europe, 'United+K' = United Kingdom, etc.

// For single location, use the following
// $extremesLocations  = array('Cana');
// $extremesLocNames   = array('Canada');

// For multiple locations, use the following
$extremesLocations  = array('World', 'North', 'South' , 'Cana', 'United+S', 'Eur', 'United+K');
$extremesLocNames   = array('World', 'Northern Hemisphere', 'Southern Hemisphere' , 'Canada', 'United States', 'Europe', 'United Kingdom');

// Default location - chosen from the $extremesLocations option
$defaultlocation    = 'United+S';

// Select a unit type for each of the above locations: 'M'=Metric or 'I'=USA/UK/AU(Imperial)
$extremesUnits      = array('I', 'I', 'I', 'I', 'I', 'I', 'I');

// Age of the cache file before re-fetch caching time, in seconds (3600 = 1 hour)
$cache_life         = '1800'; // (1800 = 30 minutes)

// Number of stations to display
$stations           = 15;

// To open location links into another tab/window
// $newtab = 'target="_self"'; // opens link in same tab/window
$newtab           = 'target="_blank"'; // opens link in a new tab/window
/////////////////////////////////////////////////////////////////////////////
//END SETTINGS///////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////

// Default location when this script is firts started
if (!isset($_GET['extremes']) ) {
  $country    = $defaultlocation;
  $selected   = $country;
  $useunits   = 'I';
  $siteCache  = 'extremesCache_'.strtolower($country).'.php';
  $stations   = $stations; // only displayed when script is firts started
}
// Default location (use same options as above)
if (isset($_GET['extremes']) && $_GET['extremes'] == false) {
  $country    = $defaultlocation;
  $selected   = $country;
  $useunits   = 'I';
  $siteCache  = 'extremesCache_'.strtolower($country).'.php';
  $stations   = $stations; // only displayed when script is firts started
}

$key = 0;
if (isset($_GET['extremes']) && $_GET['extremes'] == true) {
  $key = array_search($_GET['extremes'], $extremesLocations);
  for ($i = 0; $i <= $key; $i++) {
    $country   = $extremesLocations[$i];
    $selected  = $country;
    $useunits  = $extremesUnits[$i];
    $siteCache = 'extremesCache_'.strtolower($country).'.php';
  }
}

$locations = array(); $lc = 1;
foreach ($extremesLocations as $v)  { $locations["$lc"] = $v; $lc++; }
$XLocations = $locations;
$names = array(); $nc = 1;
foreach ($extremesLocNames as $v)  { $names["$nc"] = $v; $nc++; }
$XNames = $names;
unset($locations, $names);

/////////////////////////////////////////////////////////////////////////////
// Site to Parse
$siteSource = "http://www.ogimet.com/cgi-bin/gsynext?lang=en&state=$country&rank=20&ano=$year&mes=$month&day=$day&hora=$hour&Send=send";
/////////////////////////////////////////////////////////////////////////////

// if the cache file exists, get the file time and size 
if (file_exists($siteCache)) {
    $filemtime = filemtime($siteCache);
    $filesize = filesize($siteCache);
    if (0 == $filesize){
        $filemtime = 0;
    }
} else {
    $filemtime = 0;
}   
// check cache file age and write the new data.
$updateCache = '';
$errorRep = '<td align="center">&nbsp;</td>';
$current_time = time();
$cache_age = $current_time - $filemtime;
$tLeft = $cache_life - $cache_age;
if($tLeft < 0){$tLeft = 0;} // display negative time left as 0 
if($cache_age >= $cache_life){
   $updateCache = 1;
   $sitehtml = implode(' ', file($siteSource)); 
   if(preg_match("/OGIMET is overloaded/Uis", $sitehtml)) {
     $updateCache = '';
	 $errorRep = '<td align="center"><span style="color: yellow;">-</span></td>';
     echo "<!-- The source OGIMET is overloaded and cache file was not updated -->\n"; 
   }
}
if ($updateCache){ // re-write cache file if source has data
   $mh = fopen($siteCache, 'w');
   fwrite($mh, $sitehtml);
   fclose($mh);
   echo "<!-- The cache file expired and fresh data written -->\n";
}   
else { // open cache file and read it if not expired or source overloaded
   echo "<!-- The cache life of $cache_life seconds is valid and expires in $tLeft seconds -->\n";
   $mth = fopen($siteCache, "r");
   $filesize = filesize($siteCache);
   $sitehtml = fread($mth, $filesize);
   fclose($mth);
}

//Finds Extremes
preg_match_all('|<table bgcolor="#FFFFDD" align="center">(.*)</table>|Uis', $sitehtml, $extremes);
//Finds if Ogimet is Overloaded
preg_match('|<!--nucleo, fin del prologo -->\s+(.*)\s+<!--comienzo del epilogo-->|Uis', $sitehtml, $overload);

// Cleans Hi Temp Output
$extremes[1][0]= preg_replace('| &#176;C|', '', $extremes[1][0]);
// Cleans Lo Temp Output
$extremes[1][1]= preg_replace('| &#176;C|', '', $extremes[1][1]);
// Cleans Hi Precip Output
$extremes[1][2]= preg_replace('| mm|', '', $extremes[1][2]);

//Finds Hi Temp Extremes Locations
$extremes[1][0] = preg_replace('|a href="./|', 'a '.$newtab.' href="http://www.ogimet.com/cgi-bin/', $extremes[1][0]);
$extremes[1][0]= preg_replace('|<Td>|', '<td>', $extremes[1][0]);
$extremes[1][0]= preg_replace('|&|', '&amp;', $extremes[1][0]);
preg_match_all('|<td>(.*)</a></td>|Uis', $extremes[1][0], $hiextremesLoc);

//Finds Hi Temp Extremes Values
preg_match_all('|<font color="#\w{6}"><b>(.*)</b>|Uis', $extremes[1][0], $hiextremesValue);
//Finds Hi Temp Extremes Value Background Color
preg_match_all('|<td bgcolor="(.*)" |Uis', $extremes[1][0], $hiextremesBGcolor);
//Finds Hi Temp Extremes Value Font Color
preg_match_all('|align="right"><font color="(.*)"|Uis', $extremes[1][0], $hiextremesFcolor);
//Finds 5 Digit WMO Index Number for Station Identification
preg_match_all('|en&amp;ind=(.*)&amp;ano|Uis', $extremes[1][0], $hiStationID);

//Finds Lo Temp Extremes Locations
$extremes[1][1] = preg_replace('|a href="./|', 'a '.$newtab.' href="http://www.ogimet.com/cgi-bin/', $extremes[1][1]);
$extremes[1][1]= preg_replace('|<Td>|', '<td>', $extremes[1][1]);
$extremes[1][1]= preg_replace('|&|', '&amp;', $extremes[1][1]);
preg_match_all('|<td>(.*)</a></td>|Uis', $extremes[1][1], $loextremesLoc);

//Finds Lo Temp Extremes Values
preg_match_all('|<font color="#\w{6}"><b>(.*)</b>|Uis', $extremes[1][1], $loextremesValue);
//Finds Lo Temp Extremes Value Background Color
preg_match_all('|<td bgcolor="(.*)" |Uis', $extremes[1][1], $loextremesBGcolor);
//Finds Lo Temp Extremes Value Font Color
preg_match_all('|align="right"><font color="(.*)"|Uis', $extremes[1][1], $loextremesFcolor);

//Finds 5 Digit WMO Index Number for Station Identification
preg_match_all('|en&amp;ind=(.*)&amp;ano|Uis', $extremes[1][1], $loStationID);

//Finds Hi Precip Extremes Locations
$extremes[1][2] = preg_replace('|a href="./|', 'a '.$newtab.' href="http://www.ogimet.com/cgi-bin/', $extremes[1][2]);
$extremes[1][2]= preg_replace('|<Td>|', '<td>', $extremes[1][2]);
$extremes[1][2]= preg_replace('|&|', '&amp;', $extremes[1][2]);
preg_match_all('|<td>(.*)</a></td>|Uis', $extremes[1][2], $precipextremesLoc);

//Finds Hi Precip Extremes Values
preg_match_all('|<font color="#\w{6}"><b>(.*)</b>|Uis', $extremes[1][2], $precipextremesValue);
//Finds Hi Precip Extremes Value Background Color
preg_match_all('|<td bgcolor="(.*)" |Uis', $extremes[1][2], $precipextremesBGcolor);
//Finds Hi Precip Extremes Value Font Color
preg_match_all('|align="right"><font color="(.*)"|Uis', $extremes[1][2], $precipextremesFcolor);
//Finds 5 Digit WMO Index Number for Station Identification
preg_match_all('|en&amp;ind=(.*)&amp;ano|Uis', $extremes[1][2], $precipStationID);

// $uomTempE   = '&#176; F';
// $uomTempM   = '&#176; C';
$uomTempE   = '&#xb0;F'; // degrees Fahrenheit
$uomTempM   = '&#xb0;C'; // degrees Celcius
$uomRainE   = ' in';     // inches
$uomRainM   = ' mm';     // millimeters

// Start Unit Conversion if Needed
function CtoF($fixtemp) {
  global $useunits, $uomTempE, $uomTempM;
  if($useunits == 'I') { // convert C to F
    return number_format(((1.8 * $fixtemp) + 32.0) , 1, '.', '') . $uomTempE;
  } else {  // leave as C
    return $fixtemp * 1.0 . $uomTempM;
  }
}

function MMtoINCHES($fixrain) {
  global $useunits, $uomRainE, $uomRainM;
  if ($useunits == 'I') { // convert mm to inches
    return number_format(($fixrain * .0393700787), 2, '.', '') . $uomRainE;
  } else { // leave in mm
    return $fixrain * 1.0 . $uomRainM;
  }
}
#########################################################################################
?>
<br /><br />

<div align="left">
<table border="0" cellpadding="0" cellspacing="0" style="width: 640px;">
	<tr>
		<td>
<form action="" method="get"><strong>Choose a Region</strong><br />
    <select name="extremes" onchange="this.form.submit();">
    <?php
      if (!empty($selected)) { $defaultlocation = $selected; }
      if (count($XLocations) > 1) {
        $default = '';
        foreach ($XLocations as $k => $v)  {
          if (!empty($defaultlocation) && $defaultlocation == $v) { $default = ' selected="selected"'; }
          echo '<option value="' . $v . '"' . $default . '>' . $XNames[$k] . '</option>';
          $default = '';
        }
      } else { echo '<option value="' . $extremesLocations[0] . '">' . $extremesLocNames[0] . '</option>'; }
    ?>
    </select>
  <noscript><input name="submit" type="submit" value="Get Extremes Location" />[Enable JavaScript to select a weather extremes location]</noscript>
</form>
</td>
</tr>
</table>
<br />
<br />
<br />
<table border="0" cellpadding="5" cellspacing="0" style="width: 99%;">
<caption><span style="font-size: 115%; color: #FF0000;"><strong>Maximum Temperature Last 24h. <?php echo $month."/".$day."/".$year; ?> at <?php echo $hour ?>:00 UTC</strong></span></caption>
<tr>
  <td style="width: 5%; font-size: 90%; font-weight: bold; text-align: center;">No.</td>
  <td style="width: 70%; font-size: 90%; font-weight: bold; text-align: left;">Location</td>
  <td style="width: 10%; font-size: 90%; font-weight: bold; text-align: center;">Station ID</td>
  <td style="width: 15%; font-size: 90%; font-weight: bold; text-align: center;">Amount</td>
</tr>
<?php
for ($i = 0; $i <= ($stations-1); $i++) {
  if($i%2 ==0 ) { $bgcolor = 'E0E0FF'; }
  else { $bgcolor = 'FFFFFF'; }
?>
<tr bgcolor="#<?php echo $bgcolor ?>">
  <td style=" text-align: center;"><?php echo $hiextremesLoc[1][$i].'</a>'; ?></td>
  <td align="center"><?php echo $hiStationID[1][$i]; ?></td>
  <td align="center" bgcolor="<?php echo $hiextremesBGcolor[1][$i]; ?>">
    <font color  ="<?php echo $hiextremesFcolor[1][$i]; ?>">
      <strong><?php echo CtoF($hiextremesValue[1][$i]); ?></strong>
    </font>
  </td>
</tr>
<?php } ?>
<tr>
	<td colspan="3" style="font-size: 8px;">Script courtesy of &nbsp;Michael Holden of  
	<a href='http://www.relayweather.com/'>Relay Weather</a>. Data courtesy of <a href='http://www.ogimet.com/'>Ogimet</a></td>
</tr>
</table>

<br /><br /><br /><br />

<table border="0" cellpadding="5" cellspacing="0" style="width: 99%;">
<caption><span style="font-size: 115%; color: #4E82FE;"><strong>Minimum Temperature Last 24h. <?php echo $month."/".$day."/".$year; ?> at <?php echo $hour ?>:00 UTC</strong></span></caption>
<tr>
  <td style="width: 5%; font-size: 90%; font-weight: bold; text-align: center;">No.</td>
  <td style="width: 70%; font-size: 90%; font-weight: bold; text-align: left;">Location</td>
  <td style="width: 10%; font-size: 90%; font-weight: bold; text-align: center;">Station ID</td>
  <td style="width: 15%; font-size: 90%; font-weight: bold; text-align: center;">Amount</td>
</tr>
<?php
for ($i = 0; $i <= ($stations-1); $i++) {
  if($i%2 ==0 ) { $bgcolor = 'E0E0FF'; }
  else { $bgcolor = 'FFFFFF'; }
?>
<tr bgcolor="#<?php echo $bgcolor ?>">
  <td style=" text-align: center;"><?php echo $loextremesLoc[1][$i].'</a>'; ?></td>
  <td align="center"><?php echo $loStationID[1][$i]; ?></td>
  <td align="center" bgcolor="<?php echo $loextremesBGcolor[1][$i]; ?>">
    <font color  ="<?php echo $loextremesFcolor[1][$i]; ?>">
      <strong><?php echo CtoF($loextremesValue[1][$i]); ?></strong>
    </font>
  </td>
</tr>
<?php } ?>
<tr>
	<td colspan="3" style="font-size: 8px;">Script courtesy of &nbsp;Michael Holden of  
		<a href='http://www.relayweather.com/'>Relay Weather</a>. Data courtesy of <a href='http://www.ogimet.com/'>Ogimet</a></td>
</tr>
</table>

<br /><br /><br /><br />

<table border="0" cellpadding="5" cellspacing="0" style="width: 99%;">
<caption><span style="font-size: 115%; color: #008080;"><strong>Maximum Precipitation Last 24h. <?php echo $month."/".$day."/".$year; ?> at <?php echo $hour ?>:00 UTC</strong></span></caption>
<tr>
  <td style="width: 5%; font-size: 90%; font-weight: bold; text-align: center;">No.</td>
  <td style="width: 70%; font-size: 90%; font-weight: bold; text-align: left;">Location</td>
  <td style="width: 10%; font-size: 90%; font-weight: bold; text-align: center;">Station ID</td>
  <td style="width: 15%; font-size: 90%; font-weight: bold; text-align: center;">Amount</td>
</tr>
<?php
for ($i = 0; $i <= ($stations-1); $i++) {
  if($i%2 ==0 ) { $bgcolor = 'E0E0FF'; }
  else { $bgcolor = 'FFFFFF'; }
?>
<tr bgcolor="#<?php echo $bgcolor ?>">
  <td style=" text-align: center;"><?php echo $precipextremesLoc[1][$i].'</a>'; ?></td>
  <td align="center"><?php echo $precipStationID[1][$i]; ?></td>
  <td align="center" bgcolor="<?php echo $precipextremesBGcolor[1][$i]; ?>">
    <font color  ="<?php echo $precipextremesFcolor[1][$i]; ?>">
      <strong><?php echo MMtoINCHES($precipextremesValue[1][$i]); ?></strong>
    </font>
  </td>
</tr>
<?php } ?>
<tr>
	<td colspan="3" style="font-size: 8px;">Script courtesy of &nbsp;Michael Holden of  
		<a href='http://www.relayweather.com/'>Relay Weather</a>. Data courtesy of <a href='http://www.ogimet.com/'>Ogimet</a></td>
</tr>
</table>

<br /><br /><br />

<table width="90%" align="center" border="1">
<tr>
<td><span class="c36">Search By Station Identifier</span>
<form action="http://weather.noaa.gov/cgi-bin/nsd_lookup.pl" method="post"><span class="c16">Enter either a <strong>5-digit WMO index number</strong> or a <strong>4-character ICAO location indicator</strong>:</span><br />
<input type="text" name="station" size="5" maxlength="5" /><input type="submit" value="Search" /><input type="reset" value="Clear" /></form>
</td>
</tr>
<tr>
<td><span class="c37">Warning: Many data filters have been introduced to the above data. Use caution with this data as some extreme values can be erroneous due to unsuspected errors in synop reports. All data should be verified. Note that the values we listed here are from international released synop reports, and for certain there will be other extreme values not in this list</span></td>
</tr>
</table>

</div>