World Extremes Weather Script
Author:  Michael  (michael@relayweather.com)
Free PHP Scripts - http://www.relayweather.com/downloads.php

Version: 0.04 - 4-Dec-2010

################
# What does it do?
# ##############

This script will provide you will the last 24 hour extremes for your country or area using international
metar climate reports provided by ogimet. 

To name a few, the extremes are based on multiple stations that submit metar information (most are airports):
United States: 1845 stations
United Kingdom: 146 stations
Canada: 757 stations
To name a few.....

The script is 100% XHTML 1.0 Transitional.
Feel free to use and alter as you wish.

################
# What do I need?
# ##############

PHP 5 support is required
.. Your PHP server MUST allow PHP scripts permission to write files.

################
# How to use it:
# ##############

1) Set your settings in the "settings" section in the PHP script.
		a.	Select Country or Location
				Go here (http://www.ogimet.com/ranking.phtml.en), select your country and look in the URL for the country abbr.
				Examples: 'World' = world, 'North' = Northern Hemisphere, 'South' = Southern Hemisphere, 'Eur' = Europe, etc.
				Examples: 'Cana' = Canada, 'United+S' = United States, 'Eur' = Europe, 'United+K' = United Kingdom, etc.
				
		b.	Place your locations into the array
				For multiple locations, use the following format:
				$extremesLocations  = array('World', 'North', 'South' , 'Cana', 'United+S', 'Eur', 'United+K');
				$extremesLocNames   = array('World', 'Northern Hemisphere', 'Southern Hemisphere' , 'Canada', 'United States', 'Europe', 'United Kingdom');
		
		c.  Create blank PHP cache files and name them using the name as used in the $extremesLocations array but in lower case
				Examples: 'Cana' = extremesCache_cana.php, 'United+S' = extremesCache_united+s.php, etc..
		d.  Upload the file(s) to your server and set CHMOD=666 so it can be opened and written to.
		e.	Select your default location.  The script will default to this region when first selected:
				Example:  $defaultlocation    = 'United+S';
		f.	Select a unit type for each location('M'=Metric or 'I'=USA/UK/AU(Imperial)) Remember to keep the order
				Example:  $extremesUnits      = array('I', 'M', 'I', 'M', 'M', 'I', 'I');
		g.  Select the desired Cache life time.  The cache will only be updated on the server if this time has passed
				since the last update.  This stops the unecessary frequent retrieval of new data.  Set this to a minimum
				of "1800" (1800 seconds = 30 minutes).
		h.	Select the Number of stations to display per region.		

################
# Whats Included
# in the ZIP File
# ##############

1)	worldextremes.php  (File that does the work)
		extremesCache_cana.php  (Blank Cache File) *may not be needed based on your region selections
		extremesCache_eur.php  (Blank Cache File) *may not be needed based on your region selections
		extremesCache_north.php  (Blank Cache File) *may not be needed based on your region selections
		extremesCache_south.php  (Blank Cache File) *may not be needed based on your region selections
		extremesCache_united+k.php  (Blank Cache File) *may not be needed based on your region selections
		extremesCache_united+s.php  (Blank Cache File) *may not be needed based on your region selections
		extremesCache_world.php  (Blank Cache File)	*may not be needed based on your region selections
		worldextremesREADME.txt (This file)
		
################
# Notes
# ##############		

1)	To use this file within you webpage, call an include:
			<?php include("worldextremes.php"); ?>

That's it!  You should have the script up and running quickly.

-----------------------------------------
Comments or Suggestions
-----------------------------------------
You can see my script in use here: http://www.relayweather.com/wxworldextremes.php
Contact:  http://www.relayweather.com/wxcontact.php



